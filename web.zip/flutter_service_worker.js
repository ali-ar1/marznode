'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';

const RESOURCES = {"assets/AssetManifest.bin": "a57f16d9ef8ec3618b5767051e26abf6",
"assets/AssetManifest.bin.json": "1f4c4768f171597fa192e4e972d7f0fd",
"assets/AssetManifest.json": "327606126359e54cea407d156289559b",
"assets/assets/fonts/NotoColorEmoji.ttf": "4981d3d22bda9c3d0791c13cb612e95d",
"assets/assets/fonts/SF-Pro.ttf": "b00758ffdb3216ea93c6fc6957aa2cfa",
"assets/assets/images/active.png": "558f5b3bfef01de8879e2fa9a3c92d6c",
"assets/assets/images/admin.png": "0da55bfedf63679adb323d5e70e38b5e",
"assets/assets/images/agent.png": "1e3381e5089c8dd64c820106498082a5",
"assets/assets/images/close_menu.svg": "3a1d9b852a742b5904e5f7375018a165",
"assets/assets/images/country.png": "271f415672e2ba3f7c5ff60f19ba0fe9",
"assets/assets/images/dashboard.png": "29be7808eec5b71b47a2101a38fc15ca",
"assets/assets/images/document.png": "006cd81f61677f935533c380cb7c6d45",
"assets/assets/images/folder.png": "947640b35beb2854133cee2504c968b8",
"assets/assets/images/icloud.png": "0b8edd67e37a59b906f4b0d8e4bd921c",
"assets/assets/images/keyword.png": "d1f2f6c7ba319dede24d03fa7c78f44d",
"assets/assets/images/language_english.png": "09e28d48631213326fef6f764afe406a",
"assets/assets/images/language_persian.png": "62c112de12a119e94f2ce292c369c7d1",
"assets/assets/images/online.png": "457277b0e35e01609c530f6cdfd41712",
"assets/assets/images/on_hold.png": "366648748ca029f06956e6c1a72635a3",
"assets/assets/images/open_menu.svg": "550fd776fc326ff2ec70775100e44251",
"assets/assets/images/removed.png": "0b43127414c9a0d91030f1bf763500b8",
"assets/assets/images/settings.png": "5a980cab5c287e58e41cea79cf62e9ec",
"assets/assets/images/subs.png": "327a831932e9ef4a7a091f68ca2eb5e7",
"assets/assets/images/subscription.png": "533525fcfd6797f74f3629fe822d5863",
"assets/assets/images/user.png": "a131b65d9d7390e594abd141d8390a44",
"assets/assets/languages/en.json": "97b52f8667979acdc617266b4be82c3d",
"assets/assets/languages/fa.json": "a5dccab389005b741bb7008c0e85d401",
"assets/FontManifest.json": "de314b95335ca9d563d2cd752b2643e1",
"assets/fonts/MaterialIcons-Regular.otf": "c64a1ac55fb69167b628d0ecd178f53f",
"assets/NOTICES": "58af0290da0c49987fa5fea26023aed9",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "e986ebe42ef785b27164c36a9abc7818",
"assets/shaders/ink_sparkle.frag": "ecc85a2e95f5e9f53123dcaf8cb9b6ce",
"autofill.css": "abb188d7d153f1640b963674ca559586",
"canvaskit/canvaskit.js": "26eef3024dbc64886b7f48e1b6fb05cf",
"canvaskit/canvaskit.js.symbols": "efc2cd87d1ff6c586b7d4c7083063a40",
"canvaskit/canvaskit.wasm": "e7602c687313cfac5f495c5eac2fb324",
"canvaskit/chromium/canvaskit.js": "b7ba6d908089f706772b2007c37e6da4",
"canvaskit/chromium/canvaskit.js.symbols": "e115ddcfad5f5b98a90e389433606502",
"canvaskit/chromium/canvaskit.wasm": "ea5ab288728f7200f398f60089048b48",
"canvaskit/skwasm.js": "ac0f73826b925320a1e9b0d3fd7da61c",
"canvaskit/skwasm.js.symbols": "96263e00e3c9bd9cd878ead867c04f3c",
"canvaskit/skwasm.wasm": "828c26a0b1cc8eb1adacbdd0c5e8bcfa",
"canvaskit/skwasm.worker.js": "89990e8c92bcb123999aa81f7e203b1c",
"favicon.png": "41f7811c41269ae1801fa65f32334a9e",
"flutter.js": "4b2350e14c6650ba82871f60906437ea",
"flutter_bootstrap.js": "d7f7c91c69d50ea05abf68546e926ed1",
"icons/icon-192.png": "8effdc504108079adc5f1d00bc48513d",
"icons/icon-512.png": "ed0655fe1e69099dca3ec21bbebcb38a",
"icons/icon-maskable-192.png": "8effdc504108079adc5f1d00bc48513d",
"icons/icon-maskable-512.png": "ed0655fe1e69099dca3ec21bbebcb38a",
"index.html": "aec2f61be7282cfff3d389c2820cc189",
"/": "aec2f61be7282cfff3d389c2820cc189",
"main.dart.js": "547ee811bcc7ab752c2d7f0faab5813b",
"manifest.json": "bf1a121765d9c85ddae7a0b42a2cb5a3",
"version.json": "199afd1c38809d520978d6d902d9a8f2"};
// The application shell files that are downloaded before a service worker can
// start.
const CORE = ["main.dart.js",
"index.html",
"flutter_bootstrap.js",
"assets/AssetManifest.bin.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});
// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        // Claim client to enable caching on first launch
        self.clients.claim();
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      // Claim client to enable caching on first launch
      self.clients.claim();
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});
// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});
self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});
// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}
// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
